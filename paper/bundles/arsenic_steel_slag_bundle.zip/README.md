# Arsenic Steel Slag Bundle

本 bundle 对应论文 "钢渣驱动铁氧化-砷固定机制" 的 EnvMeta 分析配置。

## 如何使用

1. 启动 EnvMeta：`streamlit run app.py`
2. 循环图页 → 展开 "📦 Fork Bundle" → 上传本 zip
3. 准备原始数据（6 个 TSV，见论文 Data Availability）
4. 生成循环图 + 假说评分

## 内容

- `kb/elements.json`: KEGG-driven 知识库 (As/N/S/Fe × 18 通路 × 57 KO)
- `hypotheses/arsenic_steel_slag.yaml`: 9 claim 机制假说
- `config/cycle_params.yaml`: 论文 Figure 3 使用的参数

## 引用

若本 bundle 对你的工作有帮助，请引用 EnvMeta 方法学论文（见 README）。
